#include <iostream>
#include "MagicDundieCarolineArndt.h"

using namespace std;

int main() {


    MagicDundie CarlysTurn;
    CarlysTurn.playOfficeTrivia();
    cout <<endl;





    return 0;
}