//
// Created by Caroline Arndt on 11/25/18.
//

#ifndef L6B_FUNCTONS_H
#define L6B_FUNCTONS_H

#include <vector>


void numbersYouEntered(std::vector<int> myVector);

void lowestHighestValue(std::vector<int> myVector);

void firstLastValue(std::vector<int> myVector);



#endif //L6B_FUNCTONS_H
