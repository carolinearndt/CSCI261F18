/*
 * Author: Caroline Arndt
 * CSCI 261 E
 * A4
 *
 * The purpose of this lab is to use functions to create an ATM program that allows the user to
 * deposit, withdraw, and check their balance.
 *
 */

#include <iostream>
#include "Functions.h"
using namespace std;

int main() {
    startATM();
    return 0;
}